<?php
require_once("database.php");

$student_id = $_POST['student_id'];

$sql="SELECT COUNT(student_id) FROM add_attendance where student_id='$student_id'";

$result=array();

$data=mysqli_query($con,$sql);

while($row=mysqli_fetch_array($data))
{
	array_push($result,array('student_id_count'=>$row[0]));
}
echo json_encode(array('getAllPresentyCount'=>$result));

mysqli_close($con);


?>
