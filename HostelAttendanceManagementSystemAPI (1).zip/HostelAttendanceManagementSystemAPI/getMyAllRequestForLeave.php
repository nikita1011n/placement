<?php
require_once("database.php");
$student_id = $_POST['student_id'];

$sql="SELECT id,leave_start_date,leave_end_date, leave_title, leave_description,leave_proof_image,status FROM request_for_leave where student_id = '$student_id'";

$result=array();

$data=mysqli_query($con,$sql);

while($row=mysqli_fetch_array($data))
{
  array_push($result,array('id'=>$row[0],'start_date'=>$row[1],'end_date' => $row[2],'leave_title' => $row[3],'leave_description' => $row[4],'leave_proof_image'=>$row[5],'leave_status' => $row[6]));
}
echo json_encode(array('getMyAllRequestForLeave'=>$result));

mysqli_close($con);


?>
