<?php
require_once("database.php");

$student_id = $_POST['student_id'];
$sql="SELECT id,attendance_status,date_time,latitude,longitude,address FROM add_attendance where student_id='$student_id'";

$result=array();

$data=mysqli_query($con,$sql);

while($row=mysqli_fetch_array($data))
{
	array_push($result,array('id'=>$row[0],'attendance_status'=>$row[1],'date_time'=>$row[2],'latitude'=>$row[3],'longitude'=>$row[4],'address'=>$row[5]));
}
echo json_encode(array('getMyAttendance'=>$result));

mysqli_close($con);

?>
