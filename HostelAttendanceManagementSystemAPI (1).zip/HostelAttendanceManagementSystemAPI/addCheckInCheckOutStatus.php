<?php
require_once("database.php");

$student_id = $_POST['student_id'];
$status = $_POST['status'];

$sql = "insert into checkin_checkout_statustbl(student_id,status,date_time) values('$student_id','$status',now())";

$result = mysqli_query($con,$sql);

if ($result > 0) {
	$response['success'] = 1; 
	// code...
}
else
{
$response['sucess'] = 0;
}

echo json_encode($response);

?>