<?php
require_once("database.php");

$sql="select rfl.id,rfl.student_id,rs.name,rs.enrollment_no,rs.mobile_no,rfl.branch,rfl.sem,rfl.leave_start_date,rfl.leave_end_date,rfl.leave_title,rfl.leave_description,rfl.status,rfl.leave_proof_image from request_for_leave rfl inner join register_student rs on rfl.student_id = rs.id";

$result=array();

$data=mysqli_query($con,$sql);

while($row=mysqli_fetch_array($data))
{
	array_push($result,array('id'=>$row[0],'student_id'=>$row[1],'name'=>$row[2],'enrollment_no'=>$row[3],'mobile_no'=>$row[4],'branch'=>$row[5],'sem'=>$row[6],'leave_start_date'=>$row[7],'leave_end_date'=>$row[8],'leave_title'=>$row[9],'leave_description'=>$row[10],'status'=>$row[11],'leave_proof_image'=>$row[12]));
}
echo json_encode(array('getAllRequesrForLeave'=>$result));

mysqli_close($con);

?>
