<?php
require_once("database.php");

$sql="select id,name,mobile_no,email_id,gender,address,enrollment_no,branch,semester,parent_name,parent_mobile_no,parent_address,username,password from register_student";

$result=array();

$data=mysqli_query($con,$sql);

while($row=mysqli_fetch_array($data))
{
  array_push($result,array('id'=>$row[0],'name'=>$row[1],'mobile_no' => $row[2],'email_id' => $row[3],'gender' => $row[4],'address'=>$row[5],'enrollment_no' => $row[6],'branch' => $row[7],'semester' => $row[8],'parent_name' => $row[9],'parent_mobile_no' => $row[10],'parent_address' => $row[11],'username' => $row[12],'password' => $row[13]));
}
echo json_encode(array('getAllStudent'=>$result));

mysqli_close($con);


?>
