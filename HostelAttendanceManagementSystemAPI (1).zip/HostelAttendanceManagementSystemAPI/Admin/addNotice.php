<?php
require_once("database.php");

$notice_title = $_POST['notice_title'];
$notice_description = $_POST['notice_description'];

$sql = "insert into notice_board(title
,description) values('$notice_title','$notice_description')";

$result = mysqli_query($con,$sql);

if ($result > 0) {
	$response['success'] = 1; 
	// code...
}
else
{
$response['sucess'] = 0;
}

echo json_encode($response);

?>