<?php
$con = mysqli_connect("localhost","root","","hostelattendancemangementsystemdb") or die('unable to connect');
?>