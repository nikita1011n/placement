<?php
require_once("database.php");

$sql="select aa.id,aa.student_id,rs.name,rs.enrollment_no,rs.mobile_no,rs.branch,rs.semester,aa.date_time,aa.attendance_status,aa.latitude,aa.longitude,aa.address from add_attendance aa inner join register_student rs on aa.student_id = rs.id";

$result=array();

$data=mysqli_query($con,$sql);

while($row=mysqli_fetch_array($data))
{
	array_push($result,array('id'=>$row[0],'student_id'=>$row[1],'name'=>$row[2],'enrollment_no'=>$row[3],'mobile_no'=>$row[4],'branch'=>$row[5],'semester'=>$row[6],'date_time'=>$row[7],'status'=>$row[8],'latitude'=>$row[9],'longitude'=>$row[10],'address'=>$row[11]));
}
echo json_encode(array('getAllAttendance'=>$result));

mysqli_close($con);

?>
