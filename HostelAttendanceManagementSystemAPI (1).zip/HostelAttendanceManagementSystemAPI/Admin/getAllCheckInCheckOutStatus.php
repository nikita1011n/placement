<?php
require_once("database.php");

$sql="SELECT checkin_checkout_statustbl.id,checkin_checkout_statustbl.student_id,checkin_checkout_statustbl.status, checkin_checkout_statustbl.date_time,register_student.name,register_student.branch,register_student.semester FROM checkin_checkout_statustbl Left Join register_student ON checkin_checkout_statustbl.student_id = register_student.id order by checkin_checkout_statustbl.id desc";

$result=array();

$data=mysqli_query($con,$sql);

while($row=mysqli_fetch_array($data))
{
  array_push($result,array('id'=>$row[0],'student_id'=>$row[1],'status' => $row[2],'date_time' => $row[3],'name' => $row[4],'branch' => $row[5],'semester' => $row[6]));
}
echo json_encode(array('getAllCheckInCheckOutStatus'=>$result));

mysqli_close($con);


?>
