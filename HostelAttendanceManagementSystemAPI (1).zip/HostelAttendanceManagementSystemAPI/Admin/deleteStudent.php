<?php
require_once("database.php");

$student_id=$_POST['student_id'];

$sql="delete from register_student where id='$student_id'";
$result=mysqli_query($con,$sql);
if($result>0)
{
$response['success']=1;
}
else
{
	$response['success']=0;
}
echo json_encode($response);

?>