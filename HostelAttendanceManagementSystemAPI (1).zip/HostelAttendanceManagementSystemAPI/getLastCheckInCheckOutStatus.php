<?php
require_once("database.php");
$student_id = $_POST['student_id'];

$sql="SELECT id,student_id,status, date_time FROM checkin_checkout_statustbl where student_id = '$student_id' order by id desc";

$result=array();

$data=mysqli_query($con,$sql);

if($row=mysqli_fetch_array($data))
{
  array_push($result,array('id'=>$row[0],'student_id'=>$row[1],'status' => $row[2],'date_time' => $row[3]));
}
echo json_encode(array('getLastCheckInCheckOutStatus'=>$result));

mysqli_close($con);


?>
