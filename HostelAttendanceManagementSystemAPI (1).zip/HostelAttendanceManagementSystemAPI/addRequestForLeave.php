<?php
require_once("database.php");

$student_id = $_POST['student_id'];
$branch = $_POST['branch'];
$sem = $_POST['sem'];
$leave_start_date = $_POST['leave_start_date'];
$leave_end_date = $_POST['leave_end_date'];
$leave_title = $_POST['leave_title'];
$leave_description = $_POST['leave_description'];

$sql = "insert into request_for_leave(student_id,branch,sem,leave_start_date,leave_end_date,leave_title,leave_description,status) values('$student_id','$branch','$sem','$leave_start_date','$leave_end_date','$leave_title','$leave_description','Pending')";

$result = mysqli_query($con,$sql);

if ($result > 0) {
	$response['success'] = 1; 
	$response['lastinsertedid']= mysqli_insert_id($con);
}
else
{
$response['sucess'] = 0;
}

echo json_encode($response);

?>