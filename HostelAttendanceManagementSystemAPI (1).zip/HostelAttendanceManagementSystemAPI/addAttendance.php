<?php
require_once("database.php");

$student_id = $_POST['student_id'];
$attendance_status = $_POST['attendance_status'];
$latitude = $_POST['latitude'];
$longitude = $_POST['longitude'];
$address = $_POST['address'];

$sql = "insert into add_attendance(student_id,attendance_status,date_time,latitude,longitude,address) values('$student_id','$attendance_status',now(),'$latitude','$longitude','$address')";

$result = mysqli_query($con,$sql);

if ($result > 0) {
	$response['success'] = 1; 
	// code...
}
else
{
$response['sucess'] = 0;
}

echo json_encode($response);

?>