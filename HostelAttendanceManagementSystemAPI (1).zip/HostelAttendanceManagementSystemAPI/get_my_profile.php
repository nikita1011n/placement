<?php
require_once("database.php");
 $roll_no = $_POST['roll_no'];
$sql="SELECT id, name, mobile_no, email_id,roll_no,gender,branch,semester FROM register_student where roll_no = '$roll_no'";

$result=array();

$data=mysqli_query($con,$sql);

while($row=mysqli_fetch_array($data))
{
	array_push($result,array('id'=>$row[0],'name' => $row[1],'mobile_no' => $row[2],'email_id' => $row[3],'roll_no'=>$row[4],'gender' => $row[5],'branch' => $row[6],'semester' => $row[7]));
}
echo json_encode(array('getMyProfile'=>$result));

mysqli_close($con);


?>
