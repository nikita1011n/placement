<?php
require_once("database.php");
$username = $_POST['username'];
$password = $_POST['password'];

$sql = "select id,name,mobile_no,email_id,gender,address,enrollment_no,branch,semester,parent_name,parent_mobile_no,parent_address,username,password from register_student where username = '$username' and password = '$password'";

$result = mysqli_query($con,$sql);
if ($row = mysqli_fetch_array($result)) {
	$response['success'] = 1;
	$response['id'] = $row['id'];
	$response['name'] = $row['name'];
	$response['mobile_no'] = $row['mobile_no'];
	$response['email_id'] = $row['email_id'];
	$response['gender'] = $row['gender'];
	$response['address'] = $row['address'];
	$response['enrollment_no'] = $row['enrollment_no'];
	$response['branch'] = $row['branch'];
	$response['semester'] = $row['semester'];
	$response['parent_name'] = $row['parent_name'];
	$response['parent_mobile_no'] = $row['parent_mobile_no'];
	$response['parent_address'] = $row['parent_address'];
	$response['username'] = $row['username'];
	$response['password'] = $row['password'];
}
else {
	$response[success] = 0;
}
echo json_encode($response);
?>