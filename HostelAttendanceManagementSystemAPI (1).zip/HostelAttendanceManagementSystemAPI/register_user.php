<?php
require_once("database.php");

$name = $_POST['name'];
$mobile_no = $_POST['mobile_no'];
$email_id = $_POST['email_id'];
$address = $_POST['address'];
$branch = $_POST['branch'];
$sem = $_POST['sem'];
$subject = $_POST['subject'];
$roll_no = $_POST['roll_no'];
$username = $_POST['username'];
$password = $_POST['password'];

$sql = "insert into register_student(name,mobile_no,email_id,address,branch,semester,subject,roll_no,username,password) values('$name','$mobile_no','$email_id','$address','$branch','$sem','$subject','$roll_no','$username','$password')";

$result = mysqli_query($con,$sql);

if ($result > 0) {
	$response['success'] = 1; 
	// code...
}
else
{
$response['sucess'] = 0;
}

echo json_encode($response);

?>